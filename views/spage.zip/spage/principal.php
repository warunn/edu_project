<div id="main_area">
    <div class="post">
    <h2 align="center">Principal's Message.</h2>
    <table width="700">
    <tr><td><img src="<?php echo URL."views/spage/";?>principal.jpg" width="140px"> <h6 align="center">D.P. Udawaththage</h6></td><td><p>"if your actions inspire others to dream more, learn more, do more and become more, you are a leader" - john quincy Adams</p>
    <br><br>
    <p>Welcome to Central College Piliyandala!</p>
    <p>The College Staff and I are committed to meeting the needs of each and every student.</p>
    </td></tr>
    <tr><td colspan="2">
    
<p> As the Principal of Central College Piliyandala, I am delighted that the school's values align with my own personal values, including the importance of trust, respect, innovation and a sense of community. I know that the development of the school over the past few years has been significant. The future will build on these firm foundations focusing on the quality of school life, especially for the benefit of our learners.
High standards and expectations for each student in regard to academic performance, co-curricular participation, and responsible citizenship are the foundation of our school. It is with pride that we hold these high standards and ask each of our students to commit to maintaining the extraordinary record of achievement and contribution that has been the legacy of Centralians. </p>
<p><br>
Central College Piliyandala is one of the first central colleges established by Hon. C. W. W. Kannangara and has about 3600 students currently engaging in studies. Central college Piliyandala is also one of the leading schools in Sri Lanka due to facts, achievement gained by boys and girls nationally and internationally. It is my pleasure to lead these bright minds to the future.
 </p>   
    </td></tr>
    </table>
    </div>
</div>